let socket = new WebSocket('ws://localhost:2000/');
var name = "jsTest";

var closeConnect;

var command_type = {
    "None": 0,
    "Go": 1,
    "Stop": 2,
    "TurnLeft": 3,
    "TurnRight": 4,
    "TurnUp": 5,
    "TurnDown": 6,
    "Fire": 7,
    "Logout": 8,
    "Login": 9,
    "UpdateMap": 10
}

var Map;
var InteractObjects;

function send() {
    setTimeout(function () {
        if (closeConnect != "close") {
            var Random = Math.floor(Math.random() * 7.4);
            var command = {
                ClientCommand: Random,
                CommandParameter: null
            };
            JsonStr = JSON.stringify(command);

            socket.send(JsonStr);
            console.log(JsonStr);

            send();
        }
    }, 250)
}

function login() {
    send();
}

function disconect() {
    var logoutCommand = {
        ClientCommand: command_type["Logout"],
        CommandParameter: null
    };

    JsonStr = JSON.stringify(logoutCommand);
    socket.send(JsonStr);

    setTimeout(() => { location.reload(); }, 1000);
    
}

socket.onclose = function (event) {
    closeConnect = event.type;
    console.log("Close connection");
}

socket.onmessage = function (msg) {
    msg = JSON.parse(msg.data);
    if (msg.Map.MapHeight != 0 && msg.Map.MapWidth != 0)
        Map = msg.Map.Cells;
    InteractObjects = msg.Map.InteractObjects;
    console.log(InteractObjects);
}

socket.onopen = () => {
    var loginCommand = {
        ClientCommand: command_type["Login"],
        CommandParameter: name
    };

    JsonStr = JSON.stringify(loginCommand);
    socket.send(JsonStr);

    console.log("Open connection " + socket.url);
}