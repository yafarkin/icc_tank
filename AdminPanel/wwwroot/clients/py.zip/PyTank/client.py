import asyncio
import datetime
import json
import random
import time
import websockets


# URI сервера
uri = ""
# nickname
nickname = ""

COMMAND_TYPE = {"None":0,
                "Go":1,
                "Stop":2,
                "TurnLeft":3,
                "TurnRight":4,
                "TurnUp":5,
                "TurnDown":6,
                "Fire":7,
                "Logout":8,
                "Login":9,
                "UpdateMap":10}


async def run(uri, nickname):
    async with websockets.connect(uri) as websocket:
        # login
        json_command = json.dumps({"ClientCommand":COMMAND_TYPE["Login"], "CommandParameter":nickname})
        print(f"{datetime.datetime.now().time()} Логин на сервер {uri} как {nickname}")
        await websocket.send(json_command)
        flag = True

        # Бесконечный цикл, выход по KeyboardInterrupt Ctrl+C
        while flag:
            # Получение ответа сервера
            server_response = await websocket.recv()
            data = json.loads(server_response)
            
            # Разбор ответа сервера: ячейки карты
            map_cells = data['Map']['Cells']
            # Объекты на карте: бонусы, танки
            map_objects = data['Map']['InteractObjects']
            # Свой танк
            self_tank = [tank for tank in map_objects if 'Nickname' in tank and tank['Nickname'] == nickname]
  
            # Команда для танка. Следует заменить рандом собственной логикой           
            command = random.randint(1, 7)
            print(f"{datetime.datetime.now().time()} Отправлена команда {list(COMMAND_TYPE.keys())[list(COMMAND_TYPE.values()).index(command)]}")

            # Отправка запроса с командой на сервер
            json_command = json.dumps({"ClientCommand":command, "CommandParameter":"null"})
            await websocket.send(json_command)

            time.sleep(0.1)


        print("Закрытие соединения")
        json_command = json.dumps({"ClientCommand":COMMAND_TYPE["Logout"], "CommandParameter":None})


if not uri:
    print("Введите адрес сервера")
    uri = input()
    if not uri.startswith("ws://"):
        uri = 'ws://' + uri

if not nickname:
    print("Введите имя пользователя")
    nickname = input()

asyncio.get_event_loop().run_until_complete(run(uri, nickname))
asyncio.get_event_loop().run_forever()
