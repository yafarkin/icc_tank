package com.epam.battlecity.model;

import com.epam.battlecity.enums.DirectionType;
import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;
import java.util.UUID;

public class BulletObject extends BaseMovingObject {

    @SerializedName("SourceId")
    private UUID sourceId;

    @SerializedName("DamageHp")
    private BigDecimal damageHp;

    public BulletObject() {}

    public BulletObject(UUID id, Rectangle rectangle, BigDecimal speed, boolean isMoving, DirectionType direction,
                        UUID sourceId, BigDecimal damageHp) {
        super(id, rectangle, speed, isMoving, direction);
        this.sourceId = sourceId;
        this.damageHp = damageHp;
    }

    public UUID getSourceId() {
        return sourceId;
    }

    public void setSourceId(UUID sourceId) {
        this.sourceId = sourceId;
    }

    public BigDecimal getDamageHp() {
        return damageHp;
    }

    public void setDamageHp(BigDecimal damageHp) {
        this.damageHp = damageHp;
    }
}
