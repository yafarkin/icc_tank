package com.epam.battlecity.model;

import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;

public class Point {

    @SerializedName("Left")
    private BigDecimal left;

    @SerializedName("Top")
    private BigDecimal top;

    @SerializedName("LeftInt")
    private int leftInt;

    @SerializedName("TopInt")
    private int topInt;

    public Point() {}

    public Point(BigDecimal left, BigDecimal top) {
        this.left = left;
        this.top = top;
    }

    public Point(Point p) {
        this.left = p.left;
        this.top = p.top;
    }

    public int getLeftInt() {
        return leftInt;
    }

    public void setLeftInt(int leftInt) {
        this.leftInt = leftInt;
    }

    public int getTopInt() {
        return topInt;
    }

    public void setTopInt(int topInt) {
        this.topInt = topInt;
    }

    public BigDecimal getLeft() {
        return left;
    }

    public void setLeft(BigDecimal left) {
        this.left = left;
    }

    public BigDecimal getTop() {
        return top;
    }

    public void setTop(BigDecimal top) {
        this.top = top;
    }

    @Override
    public int hashCode() {
        return left.hashCode() * top.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || (obj.getClass() != Point.class))
            return false;
        Point p = (Point) obj;
        return left == p.left && top == p.top;
    }

    @Override
    public String toString() {
        return "L: " + left + ", T: " + top + ";";
    }
}
