package com.epam.battlecity.model;

import com.epam.battlecity.Settings;
import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;
import java.util.Date;

public class TankSettings extends Settings {

    @SerializedName("StartSesison")
    private Date startSessison;

    @SerializedName("FinishSesison")
    private Date finishSessison;

    @SerializedName("GameSpeed")
    private int gameSpeed = 1;

    @SerializedName("TimeOfActionUpgrades")
    private int timeOfActionUpgrades = 5000;

    @SerializedName("ChanceSpawnUpgrades")
    private double chanceSpawnUpgrades = 0.995;

    @SerializedName("TankSpeed")
    private BigDecimal tankSpeed = BigDecimal.valueOf(2);

    @SerializedName("BulletSpeed")
    private BigDecimal bulletSpeed = BigDecimal.valueOf(4);

    @SerializedName("TankDamage")
    private BigDecimal tankDamage = BigDecimal.valueOf(40);

    @SerializedName("TankMaxHP")
    private int tankMaxHP = 125;

    @SerializedName("IncreaseBulletSpeed")
    private int increaseBulletSpeed = 1;

    @SerializedName("IncreaseDamage")
    private int increaseDamage = 20;

    @SerializedName("RestHP")
    private int restHP = 25;

    @SerializedName("TimeOfInvulnerability")
    private int timeOfInvulnerability = 5000;

    @SerializedName("IncreaseHP")
    private int increaseHP = 125;

    @SerializedName("IncreaseSpeed")
    private int increaseSpeed;

    public TankSettings() {
    }

    public TankSettings(Date startSessison, Date finishSessison, int gameSpeed, int timeOfActionUpgrades,
                        double chanceSpawnUpgrades, BigDecimal tankSpeed, BigDecimal bulletSpeed, BigDecimal tankDamage,
                        int tankMaxHP, int increaseBulletSpeed, int increaseDamage, int restHP, int timeOfInvulnerability,
                        int increaseHP, int increaseSpeed) {
        this.startSessison = startSessison;
        this.finishSessison = finishSessison;
        this.gameSpeed = gameSpeed;
        this.timeOfActionUpgrades = timeOfActionUpgrades;
        this.chanceSpawnUpgrades = chanceSpawnUpgrades;
        this.tankSpeed = tankSpeed;
        this.bulletSpeed = bulletSpeed;
        this.tankDamage = tankDamage;
        this.tankMaxHP = tankMaxHP;
        this.increaseBulletSpeed = increaseBulletSpeed;
        this.increaseDamage = increaseDamage;
        this.restHP = restHP;
        this.timeOfInvulnerability = timeOfInvulnerability;
        this.increaseHP = increaseHP;
        this.increaseSpeed = increaseSpeed;
    }

    public int getGameSpeed() {
        return gameSpeed;
    }

    public void setGameSpeed(int gameSpeed) {
        this.gameSpeed = gameSpeed;
    }

    public BigDecimal getTankSpeed() {
        return tankSpeed;
    }

    public void setTankSpeed(BigDecimal tankSpeed) {
        this.tankSpeed = tankSpeed;
    }

    public BigDecimal getBulletSpeed() {
        return bulletSpeed;
    }

    public void setBulletSpeed(BigDecimal bulletSpeed) {
        this.bulletSpeed = bulletSpeed;
    }

    public BigDecimal getTankDamage() {
        return tankDamage;
    }

    public void setTankDamage(BigDecimal tankDamage) {
        this.tankDamage = tankDamage;
    }


}
