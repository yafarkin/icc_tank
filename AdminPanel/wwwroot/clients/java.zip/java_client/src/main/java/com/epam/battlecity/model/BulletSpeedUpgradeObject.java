package com.epam.battlecity.model;

import com.epam.battlecity.enums.UpgradeType;
import com.google.gson.annotations.SerializedName;

import java.util.UUID;

public class BulletSpeedUpgradeObject extends UpgradeInteractObject {

    @SerializedName("IncreaseBulletSpeed")
    private int increaseBulletSpeed;

    public BulletSpeedUpgradeObject() {}

    public BulletSpeedUpgradeObject(UUID id, Rectangle rectangle, int increaseBulletSpeed) {
        super(id, rectangle);
        this.increaseBulletSpeed = increaseBulletSpeed;
        setType(UpgradeType.BULLET_SPEED);
    }

    public int getIncreaseBulletSpeed() {
        return increaseBulletSpeed;
    }

    public void setIncreaseBulletSpeed(int increaseBulletSpeed) {
        this.increaseBulletSpeed = increaseBulletSpeed;
    }
}
