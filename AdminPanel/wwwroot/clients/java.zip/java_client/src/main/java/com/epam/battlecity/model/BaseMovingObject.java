package com.epam.battlecity.model;

import com.epam.battlecity.enums.DirectionType;
import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;
import java.util.UUID;

public class BaseMovingObject extends BaseInteractObject {

    @SerializedName("Speed")
    private BigDecimal speed;

    @SerializedName("IsMoving")
    private boolean isMoving;

    @SerializedName("Direction")
    private DirectionType direction;

    public BaseMovingObject() {}

    protected BaseMovingObject(UUID id, Rectangle rectangle, BigDecimal speed, boolean isMoving, DirectionType direction) {
        super(id, rectangle);
        this.speed = speed;
        this.isMoving = isMoving;
        this.direction = direction;
    }

    public BigDecimal getSpeed() {
        return speed;
    }

    public void setSpeed(BigDecimal speed) {
        this.speed = speed;
    }

    public boolean getMoving() {
        return isMoving;
    }

    public void setMoving(boolean moving) {
        isMoving = moving;
    }

    public DirectionType getDirection() {
        return direction;
    }

    public void setDirection(DirectionType direction) {
        this.direction = direction;
    }
}
