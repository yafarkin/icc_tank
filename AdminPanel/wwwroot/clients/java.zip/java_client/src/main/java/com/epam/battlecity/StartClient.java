package com.epam.battlecity;

import com.epam.battlecity.utils.PropertiesUtils;

public class StartClient {

    private static final String TANK_HOST = PropertiesUtils.getStringProperties("tank.host");
    private static final String TANK_DEFAULT_USER = PropertiesUtils.getStringProperties("tank.default.user");

    public static void main(String[] args) {
       WebSocketRunner.runClient(TANK_HOST,
               TANK_DEFAULT_USER);
    }
}
