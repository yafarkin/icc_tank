package com.epam.battlecity.model;

import com.epam.battlecity.utils.PropertiesUtils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Constants {

    public static final int CELL_WIDTH = PropertiesUtils.getIntProperties("tank.map.cell.width");
    public static final int CELL_HEIGHT = PropertiesUtils.getIntProperties("tank.map.cell.height");
    public static final int ADD_SECONDS = PropertiesUtils.getIntProperties("tank.map.object.add.second");
    public static final int TANK_INVULNERABILITY_TIME = PropertiesUtils.getIntProperties("tank.object.invulnerability.time");
}
