package com.epam.battlecity.model;

import com.epam.battlecity.Settings;
import com.epam.battlecity.enums.MapType;
import com.epam.battlecity.enums.ServerType;
import com.google.gson.annotations.SerializedName;

public class ServerSettings extends Settings {

    @SerializedName("SessionName")
    public String sessionName;

    @SerializedName("Port")
    public int port = 1000;

    @SerializedName("MapType")
    public MapType mapType;

    @SerializedName("Width")
    public int width = 20;

    @SerializedName("Height")
    public int height = 20;

    @SerializedName("MaxClientCount")
    public Integer maxClientCount = 10;

    @SerializedName("CountOfLifes")
    public int countOfLifes = 5;

    @SerializedName("TimeOfInvulnerabilityAfterRespawn")
    public int timeOfInvulnerabilityAfterRespawn = 5000;

    @SerializedName("MaxCountOfUpgrade")
    public int maxCountOfUpgrade = 3;

    @SerializedName("ServerType")
    public ServerType serverType;

    @SerializedName("tankSettings")
    public TankSettings tankSettings = new TankSettings();

    public String getSessionName() {
        return sessionName;
    }

    public void setSessionName(String sessionName) {
        this.sessionName = sessionName;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public MapType getMapType() {
        return mapType;
    }

    public void setMapType(MapType mapType) {
        this.mapType = mapType;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public Integer getMaxClientCount() {
        return maxClientCount;
    }

    public void setMaxClientCount(Integer maxClientCount) {
        this.maxClientCount = maxClientCount;
    }

    public int getCountOfLifes() {
        return countOfLifes;
    }

    public void setCountOfLifes(int countOfLifes) {
        this.countOfLifes = countOfLifes;
    }

    public int getTimeOfInvulnerabilityAfterRespawn() {
        return timeOfInvulnerabilityAfterRespawn;
    }

    public void setTimeOfInvulnerabilityAfterRespawn(int timeOfInvulnerabilityAfterRespawn) {
        this.timeOfInvulnerabilityAfterRespawn = timeOfInvulnerabilityAfterRespawn;
    }

    public int getMaxCountOfUpgrade() {
        return maxCountOfUpgrade;
    }

    public void setMaxCountOfUpgrade(int maxCountOfUpgrade) {
        this.maxCountOfUpgrade = maxCountOfUpgrade;
    }

    public ServerType getServerType() {
        return serverType;
    }

    public void setServerType(ServerType serverType) {
        this.serverType = serverType;
    }

    public TankSettings getTankSettings() {
        return tankSettings;
    }

    public void setTankSettings(TankSettings tankSettings) {
        this.tankSettings = tankSettings;
    }
}
