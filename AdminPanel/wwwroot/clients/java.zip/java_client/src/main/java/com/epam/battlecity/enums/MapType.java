package com.epam.battlecity.enums;

public enum MapType {

    BASE,
    BASE2
}
