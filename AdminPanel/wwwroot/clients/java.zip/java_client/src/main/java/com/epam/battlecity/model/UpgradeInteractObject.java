package com.epam.battlecity.model;

import com.epam.battlecity.enums.UpgradeType;
import com.google.gson.annotations.SerializedName;

import java.util.Date;
import java.util.UUID;

public class UpgradeInteractObject extends BaseInteractObject{

    @SerializedName("SpawnTime")
    private Date spawnTime;

    @SerializedName("DespawnTime")
    private Date despawnTime;

    @SerializedName("Type")
    private UpgradeType type;

    public UpgradeInteractObject() {}

    public UpgradeInteractObject(UUID id, Rectangle rectangle) {
        super(id, rectangle);
        this.spawnTime = new Date();
        this.despawnTime = new Date(this.spawnTime.getTime() + Constants.ADD_SECONDS);
    }

    public Date getSpawnTime() {
        return spawnTime;
    }

    public void setSpawnTime(Date spawnTime) {
        this.spawnTime = spawnTime;
    }

    public Date getDespawnTime() {
        return despawnTime;
    }

    public void setDespawnTime(Date despawnTime) {
        this.despawnTime = despawnTime;
    }

    public UpgradeType getType() {
        return type;
    }

    public void setType(UpgradeType type) {
        this.type = type;
    }
}
