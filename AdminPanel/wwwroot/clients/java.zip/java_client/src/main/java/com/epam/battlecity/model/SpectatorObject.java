package com.epam.battlecity.model;

import java.math.BigDecimal;
import java.util.UUID;

public class SpectatorObject extends BaseInteractObject {

    public SpectatorObject() {}

    public SpectatorObject(UUID id) {
        super(id, new Rectangle(new Point(new BigDecimal(0), new BigDecimal(0)),
                new BigDecimal(0),
                new BigDecimal(0)));
    }
}
