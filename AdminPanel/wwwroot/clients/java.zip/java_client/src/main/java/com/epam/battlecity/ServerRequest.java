package com.epam.battlecity;

import com.epam.battlecity.enums.ClientCommandType;

import java.io.Serializable;

public class ServerRequest implements Serializable {

    private ClientCommandType clientCommand;
    private String commandParameter = "";

    public ServerRequest() {}

    public ServerRequest(ClientCommandType clientCommand) {
        this.clientCommand = clientCommand;
    }

    public ServerRequest(ClientCommandType clientCommand, String commandParameter) {
        this.clientCommand = clientCommand;
        this.commandParameter = commandParameter;
    }

    public ClientCommandType getClientCommand() {
        return clientCommand;
    }

    public void setClientCommand(ClientCommandType clientCommand) {
        this.clientCommand = clientCommand;
    }

    public String getCommandParameter() {
        return commandParameter;
    }

    public void setCommandParameter(String commandParameter) {
        this.commandParameter = commandParameter;
    }
}
