package com.epam.battlecity;

import com.epam.battlecity.model.TankObject;
import com.epam.battlecity.model.TankMap;
import com.epam.battlecity.model.TankSettings;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ServerResponse implements Serializable {

    @SerializedName("Map")
    private TankMap tankMap;

    @SerializedName("Tank")
    private TankObject tankObject;

    @SerializedName("IsSettingsChanged")
    private boolean isSettingsChanged;

    @SerializedName("Settings")
    private Settings settings;

    public ServerResponse() {}

    public ServerResponse(TankMap tankMap, TankObject tankObject, boolean isSettingsChanged, Settings settings) {
        this.tankMap = tankMap;
        this.tankObject = tankObject;
        this.isSettingsChanged = isSettingsChanged;
        this.settings = settings;
    }

    public TankMap getTankMap() {
        return tankMap;
    }

    public void setTankMap(TankMap tankMap) {
        this.tankMap = tankMap;
    }

    public TankObject getTankObject() {
        return tankObject;
    }

    public void setTankObject(TankObject tankObject) {
        this.tankObject = tankObject;
    }

    public boolean isSettingsChanged() {
        return isSettingsChanged;
    }

    public void setSettingsChanged(boolean settingsChanged) {
        isSettingsChanged = settingsChanged;
    }

    public Settings getSettings() {
        return settings;
    }

    public void setSettings(Settings settings) {
        this.settings = settings;
    }
}


