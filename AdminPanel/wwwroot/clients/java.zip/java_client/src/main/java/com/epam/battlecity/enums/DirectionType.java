package com.epam.battlecity.enums;

public enum DirectionType {

    LEFT,
    RIGHT,
    UP,
    DOWN
}
