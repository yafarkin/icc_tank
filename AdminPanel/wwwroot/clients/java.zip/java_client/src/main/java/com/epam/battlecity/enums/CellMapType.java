package com.epam.battlecity.enums;

public enum CellMapType {

    VOID,
    WATER,
    GRASS,
    WALL,
    DESTRUCTIVE_WALL
}
