package com.epam.battlecity.model;

import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

public class HealthObject extends BaseInteractObject {

    @SerializedName("RestHP")
    private BigDecimal restHP;

    @SerializedName("SpawnTime")
    private Date spawnTime;

    @SerializedName("DespawnTime")
    private Date despawnTime;

    public HealthObject() {}

    public HealthObject(UUID id, Rectangle rectangle) {
        super(id, rectangle);
        this.restHP = BigDecimal.valueOf(25);
        this.spawnTime = new Date();
        this.despawnTime = new Date(this.spawnTime.getTime() + Constants.ADD_SECONDS);
    }

    public BigDecimal getRestHP() {
        return restHP;
    }

    public void setRestHP(BigDecimal restHP) {
        this.restHP = restHP;
    }

    public Date getSpawnTime() {
        return spawnTime;
    }

    public void setSpawnTime(Date spawnTime) {
        this.spawnTime = spawnTime;
    }

    public Date getDespawnTime() {
        return despawnTime;
    }

    public void setDespawnTime(Date despawnTime) {
        this.despawnTime = despawnTime;
    }
}
