package com.epam.battlecity.model;

import com.epam.battlecity.enums.UpgradeType;
import com.google.gson.annotations.SerializedName;

import java.util.UUID;

public class SpeedUpgradeObject extends UpgradeInteractObject {

    @SerializedName("IncreaseSpeed")
    private int increaseSpeed;

    public SpeedUpgradeObject() {}

    public SpeedUpgradeObject(UUID id, Rectangle rectangle, int increaseSpeed) {
        super(id, rectangle);
        this.increaseSpeed = increaseSpeed;
        setType(UpgradeType.SPEED);
    }

    public int getIncreaseSpeed() {
        return increaseSpeed;
    }

    public void setIncreaseSpeed(int increaseSpeed) {
        this.increaseSpeed = increaseSpeed;
    }
}
