package com.epam.battlecity.model;

import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;

public class Rectangle {

    @SerializedName("LeftCorner")
    private Point leftCorner;

    @SerializedName("Width")
    private BigDecimal width;

    @SerializedName("Height")
    private BigDecimal height;

    @SerializedName("WidthInt")
    private int widthInt;

    @SerializedName("HeightInt")
    private int heightInt;

    public Rectangle() {}

    public Rectangle(Rectangle rectangle) {
        this.leftCorner = new Point(rectangle.leftCorner);
        this.width = rectangle.width;
        this.height = rectangle.height;
    }

    public Rectangle(Point leftCorner, BigDecimal width, BigDecimal height) {
        this.leftCorner = leftCorner;
        this.width = width;
        this.height = height;
    }

    public int getWidthInt() {
        return widthInt;
    }

    public void setWidthInt(int widthInt) {
        this.widthInt = widthInt;
    }

    public int getHeightInt() {
        return heightInt;
    }

    public void setHeightInt(int heightInt) {
        this.heightInt = heightInt;
    }

    public Point getLeftCorner() {
        return leftCorner;
    }

    public void setLeftCorner(Point leftCorner) {
        this.leftCorner = leftCorner;
    }

    public BigDecimal getWidth() {
        return width;
    }

    public void setWidth(BigDecimal width) {
        this.width = width;
    }

    public BigDecimal getHeight() {
        return height;
    }

    public void setHeight(BigDecimal height) {
        this.height = height;
    }
}
