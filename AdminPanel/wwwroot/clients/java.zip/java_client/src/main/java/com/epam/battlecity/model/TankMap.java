package com.epam.battlecity.model;

import com.epam.battlecity.enums.CellMapType;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class TankMap <T extends BaseInteractObject> {

    @SerializedName("Cells")
    private CellMapType[][] cells;

    @SerializedName("InteractObjects")
    private List<T> interactObjects;

    @SerializedName("MapWidth")
    private int mapWidth;

    @SerializedName("MapHeight")
    private int mapHeight;

    @SerializedName("CellWidth")
    private int cellWidth;

    @SerializedName("CellHeight")
    private int cellHeight;

    public TankMap() {}

    public TankMap(CellMapType[][] cells) {
        this.cells = cells;

        if (cells != null) {
            this.mapWidth = cells[1].length;
            this.mapHeight = cells.length;
        }

        this.cellWidth = Constants.CELL_WIDTH;
        this.cellHeight = Constants.CELL_HEIGHT;

        this.interactObjects = new ArrayList<T>();
    }

    public TankMap(TankMap tankMap, List<T> interactObjects) {
        this.interactObjects = new ArrayList<T>(interactObjects);
        if(tankMap != null)
            tankMap.cells.clone();
    }

    public CellMapType[][] getCells() {
        return cells;
    }

    public void setCells(CellMapType[][] cells) {
        this.cells = cells;
    }

    public List<T> getInteractObjects() {
        return interactObjects;
    }

    public void setInteractObjects(List<T> interactObjects) {
        this.interactObjects = interactObjects;
    }

    public int getMapWidth() {
        return mapWidth;
    }

    public void setMapWidth(int mapWidth) {
        this.mapWidth = mapWidth;
    }

    public int getMapHeight() {
        return mapHeight;
    }

    public void setMapHeight(int mapHeight) {
        this.mapHeight = mapHeight;
    }

    public int getCellWidth() {
        return cellWidth;
    }

    public void setCellWidth(int cellWidth) {
        this.cellWidth = cellWidth;
    }

    public int getCellHeight() {
        return cellHeight;
    }

    public void setCellHeight(int cellHeight) {
        this.cellHeight = cellHeight;
    }

}
