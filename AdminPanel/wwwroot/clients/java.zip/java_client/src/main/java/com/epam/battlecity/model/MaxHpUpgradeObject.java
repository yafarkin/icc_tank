package com.epam.battlecity.model;

import com.epam.battlecity.enums.UpgradeType;
import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;
import java.util.UUID;

public class MaxHpUpgradeObject extends UpgradeInteractObject {

    @SerializedName("IncreaseHP")
    private BigDecimal increaseHP;

    public MaxHpUpgradeObject() {}

    public MaxHpUpgradeObject(UUID id, Rectangle rectangle, int increaseHP) {
        super(id, rectangle);
        this.increaseHP = BigDecimal.valueOf(increaseHP);
        setType(UpgradeType.MAXHP);
    }

    public BigDecimal getIncreaseHP() {
        return increaseHP;
    }

    public void setIncreaseHP(BigDecimal increaseHP) {
        this.increaseHP = increaseHP;
    }
}
