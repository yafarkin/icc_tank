package com.epam.battlecity;

import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;
import java.util.Date;

public abstract class Settings {

    @SerializedName("StartSesison")
    Date startSessison;

    @SerializedName("FinishSesison")
    Date finishSessison;

    @SerializedName("GameSpeed")
    int gameSpeed;

    @SerializedName("TimeOfActionUpgrades")
    int timeOfActionUpgrades;

    @SerializedName("ChanceSpawnUpgrades")
    double chanceSpawnUpgrades;

    @SerializedName("TankSpeed")
    BigDecimal tankSpeed;

    @SerializedName("BulletSpeed")
    BigDecimal bulletSpeed;

    @SerializedName("TankDamage")
    BigDecimal tankDamage;

    @SerializedName("TankMaxHP")
    int tankMaxHP;

    @SerializedName("IncreaseBulletSpeed")
    int increaseBulletSpeed;

    @SerializedName("IncreaseDamage")
    int increaseDamage;

    @SerializedName("RestHP")
    int restHP;

    @SerializedName("TimeOfInvulnerability")
    int timeOfInvulnerability;

    @SerializedName("IncreaseHP")
    int increaseHP;

    @SerializedName("IncreaseSpeed")
    int increaseSpeed;
}
