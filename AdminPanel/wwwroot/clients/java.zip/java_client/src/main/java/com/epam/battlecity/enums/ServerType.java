package com.epam.battlecity.enums;

public enum ServerType {

    BATLLE_CITY
}
