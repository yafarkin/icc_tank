package com.epam.battlecity.model;

import com.epam.battlecity.enums.UpgradeType;
import com.google.gson.annotations.SerializedName;

import java.util.UUID;

public class DamageUpgradeObject extends UpgradeInteractObject {

    @SerializedName("IncreaseDamage")
    private int increaseDamage;

    public DamageUpgradeObject() {}

    public DamageUpgradeObject(UUID id, Rectangle rectangle, int increaseDamage) {
        super(id, rectangle);
        this.increaseDamage = increaseDamage;
        setType(UpgradeType.DAMAGE);
    }

    public int getIncreaseDamage() {
        return increaseDamage;
    }

    public void setIncreaseDamage(int increaseDamage) {
        this.increaseDamage = increaseDamage;
    }
}
