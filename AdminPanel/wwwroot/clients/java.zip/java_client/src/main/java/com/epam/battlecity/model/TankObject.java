package com.epam.battlecity.model;

import com.epam.battlecity.enums.DirectionType;
import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;
import java.util.UUID;

public class TankObject extends BaseMovingObject {

    @SerializedName("Tag")
    private String tag;

    @SerializedName("Nickname")
    private String nickname;

    @SerializedName("MaximumHp")
    private BigDecimal maximumHp;

    @SerializedName("Hp")
    private BigDecimal hp;

    @SerializedName("Score")
    private BigDecimal score;

    @SerializedName("BulletSpeed")
    private BigDecimal bulletSpeed;

    @SerializedName("Damage")
    private BigDecimal damage;

    @SerializedName("IsDead")
    private boolean isDead;

    @SerializedName("IsInvulnerable")
    private boolean isInvulnerable = false;

    @SerializedName("MaximumLives")
    private int maximumLives;

    @SerializedName("Lives")
    private int lives;

    public TankObject() {}

    public TankObject(UUID id, Rectangle rectangle, BigDecimal speed, boolean isMoving, BigDecimal maximumHp,
                      BigDecimal hp, String nickname, String tag, int maximumLives, int lives, BigDecimal damage) {
        super(id, rectangle, speed, isMoving, DirectionType.LEFT);
        this.maximumHp = maximumHp;
        this.hp = hp;
        this.tag = tag;
        this.nickname = nickname;
        this.score = BigDecimal.valueOf(0);
        this.bulletSpeed = BigDecimal.valueOf(7);
        this.damage = damage;
        this.maximumLives = maximumLives;
        this.lives = lives;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public BigDecimal getMaximumHp() {
        return maximumHp;
    }

    public void setMaximumHp(BigDecimal maximumHp) {
        this.maximumHp = maximumHp;
    }

    public BigDecimal getHp() {
        return hp;
    }

    public void setHp(BigDecimal hp) {
        this.hp = hp;
    }

    public BigDecimal getScore() {
        return score;
    }

    public void setScore(BigDecimal score) {
        this.score = score;
    }

    public BigDecimal getBulletSpeed() {
        return bulletSpeed;
    }

    public void setBulletSpeed(BigDecimal bulletSpeed) {
        this.bulletSpeed = bulletSpeed;
    }

    public BigDecimal getDamage() {
        return damage;
    }

    public void setDamage(BigDecimal damage) {
        this.damage = damage;
    }

    public boolean isDead() {
        return isDead;
    }

    public void setDead(boolean dead) {
        isDead = dead;
    }

    public boolean isInvulnerable() {
        return isInvulnerable;
    }

    public void setInvulnerable(boolean invulnerable) {
        isInvulnerable = invulnerable;
    }

    public int getMaximumLives() {
        return maximumLives;
    }

    public void setMaximumLives(int maximumLives) {
        this.maximumLives = maximumLives;
    }

    public int getLives() {
        return lives;
    }

    public void setLives(int lives) {
        this.lives = lives;
    }
}
