package com.epam.battlecity.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesUtils {

    private static final String CONFIG = "src/main/resources/config.properties";
    private static Properties props;

    public static Properties getProps() {

        try {
            props = new Properties();
            props.load(new FileInputStream(new File(CONFIG)));
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
        return props;
    }

    public static String getStringProperties(String key) {
        return getProps().getProperty(key);
    }

    public static int getIntProperties(String key) {
        return Integer.parseInt(getProps().getProperty(key));
    }

}
