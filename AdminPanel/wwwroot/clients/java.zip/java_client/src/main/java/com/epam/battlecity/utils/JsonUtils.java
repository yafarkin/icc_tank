package com.epam.battlecity.utils;

import com.google.gson.Gson;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JsonUtils {

    private static final String CLASS_PATTERN = "\\.([^\\.\\,]\\w{1,})\\,";
    private static final String TANK_MODEL_PACKAGE = PropertiesUtils.getProps().getProperty("tank.model.package");
    private static Pattern pattern = Pattern.compile(CLASS_PATTERN);

    Gson gson = new Gson();

    public String toJson(Object obj) {
        return gson.toJson(obj);
    }

    public Object fromJson(JSONObject json, Class cl) {
        return gson.fromJson(json.toString(), cl);
    }

    public List<Object> fromJsonType(JSONObject json) throws ClassNotFoundException {
        JSONArray list = json.getJSONObject("Map").getJSONArray("InteractObjects");
        List<Object> result = new ArrayList<Object>();

        if(!list.isEmpty()) {
            for (int i = 0; i < list.length(); i++) {
                String str = (String) list.getJSONObject(i).get("$type");
                Matcher m = pattern.matcher(str);
                m.find();
                str = m.group(1);
                result.add(gson.fromJson(list.getJSONObject(i).toString(), Class.forName(TANK_MODEL_PACKAGE + str)));
            }
        }

        return result;
    }
}
