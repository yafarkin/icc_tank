package com.epam.battlecity;

import com.epam.battlecity.enums.ClientCommandType;
import com.epam.battlecity.utils.JsonUtils;
import com.epam.battlecity.utils.UrlParser;
import org.eclipse.jetty.util.ssl.SslContextFactory;
import org.eclipse.jetty.websocket.api.RemoteEndpoint;
import org.eclipse.jetty.websocket.api.UpgradeException;
import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.annotations.*;
import org.eclipse.jetty.websocket.client.WebSocketClient;
import org.json.JSONObject;

import java.io.IOException;
import java.net.ConnectException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class WebSocketRunner{

    public static final String WS_URI_PATTERN = "%s://%s";

    public static boolean PRINT_TO_CONSOLE = true;
    public static int TIMEOUT = 1000;
    public static Integer ATTEMPTS = 5;

    private static JsonUtils jsonUtils = new JsonUtils();

    private Session session;
    private WebSocketClient client;
    private Runnable onClose;
    private boolean forceClose;
    private URI uri;
    private ServerResponse response = new ServerResponse();

    public WebSocketRunner() {
        this.forceClose = false;
    }

    public static WebSocketRunner runClient(String url, String userName) {
        UrlParser parser = new UrlParser(url);
        return run(parser.protocol, parser.server, userName, ATTEMPTS);
    }

    private static WebSocketRunner run(String protocol,
                                       String server,
                                       String userName,
                                       int countAttempts) {
        return run(getUri(protocol, server), userName, countAttempts);
    }

    private static URI getUri(String protocol, String server) {
        try {
            String url = String.format(WS_URI_PATTERN, protocol, server);
            return new URI(url);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    public static WebSocketRunner run(URI uri, String userName, int countAttempts) {
        try {
            WebSocketRunner client = new WebSocketRunner();
            client.start(uri, countAttempts);

            client.login(client.session, userName);

            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                if (client != null) {
                    client.close();
                }
            }));

            //Example for sending request to server
            while(client.session.isOpen()) {
                Thread.sleep(TIMEOUT);
                client.sendMessage(client.session, new ServerRequest(ClientCommandType.FIRE));
                print("Sended to server " + ClientCommandType.FIRE);

            }

            return client;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void start(URI uri, int countAttempts) throws Exception {
        this.uri = uri;

        client = createClient();
        client.start();

        onClose = () -> {
            if (forceClose) {
                return;
            }

            printReconnect();
            connectLoop(countAttempts);
        };

        connectLoop(countAttempts);
    }

    private WebSocketClient createClient() {
        if (UrlParser.WSS_PROTOCOL.equals(uri.getScheme())) {
            SslContextFactory ssl = new SslContextFactory(true);
            ssl.setValidateCerts(false);
            return new WebSocketClient(ssl);
        }

        if (UrlParser.WS_PROTOCOL.equals(uri.getScheme())) {
            return new WebSocketClient();
        }

        throw new UnsupportedOperationException("Unsupported WebSocket protocol: " + uri.getScheme());
    }

    private void login(Session session, String userName) throws IOException {
        print("Login to server as '" + userName + "' ...");

        ServerRequest request = new ServerRequest(ClientCommandType.LOGIN, userName);
        sendMessage(session, request);

        print("Login is successful");
    }

    public void sendMessage(Session session, ServerRequest request) throws IOException {
        try {
            session.getRemote().sendString(jsonUtils.toJson(request));
        } catch (RuntimeException e) {
            print(e);
        }
    }

    public void close() {
        forceClose = true;
        try {
            if (session != null && session.isOpen()) {
                session.close();
            }
            client = null;
        } catch (Exception e) {
            print(e);
        }
    }

    @WebSocket(maxTextMessageSize = 3000000)
    public class ClientSocket {

        @OnWebSocketConnect
        public void onConnect(Session session) {
            print("Opened connection");
        }

        @OnWebSocketClose
        public void onClose(int closeCode, String message) {
            if (onClose != null) {
                onClose.run();
            }
            print("Closed with message: '" + message + "' and code: " + closeCode);
        }

        @OnWebSocketError
        public void onError(Session session, Throwable reason) {
            if (isUnauthorizedAccess(reason)) {
                print("Connection error: Unauthorized access. Please register user and/or write valid EMAIL/CODE in the client.");
            } else {
                print("Error with message: '" + reason.toString());
            }
        }

        @OnWebSocketMessage
        public void onMessage(String data) {
            try {
                JSONObject json = new JSONObject(data);
                response = (ServerResponse) jsonUtils.fromJson(json, ServerResponse.class);
                response.getTankMap().setInteractObjects(jsonUtils.fromJsonType(json));

                //Example getting data from server
                print(response.getTankObject().toString());
                printBreak();

            } catch (Exception e) {
                print("Error processing data: " + data);
                print(e);
            }
        }
    }

    private boolean isUnauthorizedAccess(Throwable exception) {
        return exception instanceof UpgradeException
                && ((UpgradeException) exception).getResponseStatusCode() == 401;
    }

    private boolean isConnectionRefused(Throwable exception) {
        return exception instanceof ConnectException
                && "Connection refused: no further information".equals(exception.getMessage());
    }

    private void connectLoop(int countAttempts) {
        while (countAttempts-- > 0) {
            try {
                tryToConnect();
                break;
            } catch (ExecutionException e) {
                print(e.toString());
                if (!isUnauthorizedAccess(e.getCause()) && !isConnectionRefused(e.getCause())) {
                    print(e);
                }
                printReconnect();
            } catch (Exception e) {
                print(e);
                printReconnect();
            }
        }
    }

    private void printReconnect() {
        print("Waiting before reconnect...");
        printBreak();
        sleep(TIMEOUT);
    }

    private void tryToConnect() throws Exception {
        print(String.format("Connecting to '%s'...", uri));

        if (session != null) {
            session.close();
        }

        session = client.connect(new ClientSocket(), uri)
                .get(TIMEOUT, TimeUnit.MILLISECONDS);
    }

    private void sleep(int mills) {
        try {
            Thread.sleep(mills);
        } catch (InterruptedException e) {
            print(e);
        }
    }

    private void printBreak() {
        print("-------------------------------------------------------------");
    }

    public static void print(String message) {
        if (PRINT_TO_CONSOLE) {
            System.out.println(DateFormat.getTimeInstance().format(new Date()) + " " + message);
        }
    }

    private void print(Exception e) {
        if (PRINT_TO_CONSOLE) {
            e.printStackTrace(System.out);
        }
    }


}
