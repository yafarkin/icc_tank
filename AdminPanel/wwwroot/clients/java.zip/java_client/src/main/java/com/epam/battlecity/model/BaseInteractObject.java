package com.epam.battlecity.model;

import com.google.gson.annotations.SerializedName;

import java.util.UUID;

public class BaseInteractObject {

    @SerializedName("Id")
    private UUID id;

    @SerializedName("Rectangle")
    private Rectangle rectangle;

    public BaseInteractObject() {}

    protected BaseInteractObject(UUID id, Rectangle rectangle) {
        this.id = id;
        this.rectangle = rectangle;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Rectangle getRectangle() {
        return rectangle;
    }

    public void setRectangle(Rectangle rectangle) {
        this.rectangle = rectangle;
    }
}
