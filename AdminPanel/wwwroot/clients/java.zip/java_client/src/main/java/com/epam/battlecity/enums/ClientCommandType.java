package com.epam.battlecity.enums;

public enum ClientCommandType {
    NONE,
    GO,
    STOP,
    TURN_LEFT,
    TURN_RIGHT,
    TURN_UP,
    TURN_DOWN,
    FIRE,
    LOGOUT,
    LOGIN,
    UPDATE_MAP
}
