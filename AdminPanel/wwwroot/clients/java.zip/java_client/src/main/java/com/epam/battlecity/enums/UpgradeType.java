package com.epam.battlecity.enums;

public enum UpgradeType {

    HEALTH,
    BULLET_SPEED,
    DAMAGE,
    SPEED,
    MAXHP,
    INVULNERABILITY
}
