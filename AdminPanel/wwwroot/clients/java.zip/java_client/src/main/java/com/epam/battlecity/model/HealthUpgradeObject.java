package com.epam.battlecity.model;

import com.epam.battlecity.enums.UpgradeType;
import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;
import java.util.UUID;

public class HealthUpgradeObject extends UpgradeInteractObject {

    @SerializedName("RestHP")
    private BigDecimal restHP;

    public HealthUpgradeObject() {}

    public HealthUpgradeObject(UUID id, Rectangle rectangle, int restHP) {
        super(id, rectangle);
        this.restHP = BigDecimal.valueOf(restHP);
        setType(UpgradeType.HEALTH);
    }

    public BigDecimal getRestHP() {
        return restHP;
    }

    public void setRestHP(BigDecimal restHP) {
        this.restHP = restHP;
    }
}
