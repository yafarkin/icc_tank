package com.epam.battlecity.utils;

import java.net.MalformedURLException;
import java.net.URL;

public class UrlParser {

    public static final String WSS_PROTOCOL = "wss";
    public static final String WS_PROTOCOL = "ws";
    public static final String HTTPS_PROTOCOL = "https";

    public String protocol;
    public String server;

    public UrlParser(String uri) {
        try {
            URL url = new URL(uri);
            protocol = (url.getProtocol().equals(HTTPS_PROTOCOL))? WSS_PROTOCOL : WS_PROTOCOL;
            server = url.getHost() + portPart(url.getPort());
        } catch (MalformedURLException e) {
            throw new RuntimeException("Please set url in format " +
                    "'http://server:port'",
                    e);
        }
    }

    private IllegalArgumentException badUrl() {
        return new IllegalArgumentException("Bad web socket server url, expected: http://server:port");
    }

    private String portPart(int port) {
        return (port == -1) ? "" : (":" + port);
    }

    @Override
    public String toString() {
        return "UrlParser{" +
                "server='" + server + '}';
    }

}
